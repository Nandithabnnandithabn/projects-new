
//         var birds=[
//   {img:"https://cdn.pixabay.com/photo/2011/09/27/18/52/bird-9950_1280.jpg"
// ,name1:"sparrow",
// age:"2yrs",
// color:"brown"},
// {
//   img:"https://cdn.pixabay.com/photo/2017/02/07/11/45/eagle-2045655_640.jpg"
// ,name1:"Eagle",
// age:"5yrs",
// color:"black and white"
// },
// {
//   img:"https://cdn.pixabay.com/photo/2015/06/21/20/12/peafowl-816981_640.jpg"
// ,name1:"peacock",
// age:"5yrs",
// color:"black and white"
// },
// {
//   img:"https://cdn.pixabay.com/photo/2020/02/27/13/21/rock-dove-4884627_1280.jpg"
// ,name1:"pigeon",
// age:"1yrs",
// color:"black and white"
// },
// {
//   img:"https://cdn.pixabay.com/photo/2018/02/17/08/05/kingfisher-3159334_640.jpg"
// ,name1:"kingfisher",
// age:"5yrs",
// color:"black and white"
// },
// {
//   img:"https://cdn.pixabay.com/photo/2016/11/29/05/32/rooster-1867562_1280.jpg "
// ,name1:"Rooster",
// age:"1yrs",
// color:"black and white"
// }
// ]


// var num=0
// var prev=document.querySelector("#prev")
// var next=document.querySelector("#next")
// var img=document.querySelector("img")
// var paras=document.querySelectorAll("p")


// window.addEventListener("DOMContentLoaded",()=>{
//   img.src=birds[num].img
// paras[0].innerText=birds[num].name1
// paras[1].innerText=birds[num].age
// paras[2].innerText=birds[num].color

// })



// prev.addEventListener("click",()=>{
//   if(num<0)
//   {
//     num=birds.length-1
//   }
// img.src=birds[num].img
// paras[0].innerText=birds[num].name1
// paras[1].innerText=birds[num].age
// paras[2].innerText=birds[num].color
// num--
// })
// next.addEventListener("click",()=>
// {
//   if(num>birds.length-1)
//   {
//     num=0
//   }
// img.src=birds[num].img
// paras[0].innerText=birds[num].name1
// paras[1].innerText=birds[num].age
// paras[2].innerText=birds[num].color
// num++
// })

// setInterval((
  
// )=>{
//   if(num>birds.length-1)
//   {
//     num=0
//   }
// img.src=birds[num].img
// paras[0].innerText=birds[num].name1
// paras[1].innerText=birds[num].age
// paras[2].innerText=birds[num].color
// num++
// },10000)


var birds=[
    {
         img:"https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/7beee9cb3cfe9ccf.jpg?q=20"
    },
    {
        img:"https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/454ba4d96248fb5b.jpg?q=20"

    },
    {
        img:"https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/2b43a232e3d86f58.jpeg?q=20"
    }
    ,
    {
        img:"https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/162b16e014373113.jpg?q=20"
    },
    {
        img:"https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/7bb7f4230a80d9a2.jpeg?q=20"
    },
    {
        img:"https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/78f0374b0191d762.jpg?q=20"
    }

]
 var num=0
 var prev=document.querySelector("#prev")
 var next=document.querySelector("#next")
 var img=document.querySelector("#dol")
 

 window.addEventListener("DOMContentLoaded",()=>{
  img.src=birds[num].img
})


prev.addEventListener("click",()=>{
  if(num<0)
  {
    num=birds.length-1
  }
img.src=birds[num].img
num--
})
next.addEventListener("click",()=>
{
   if(num>birds.length-1)
   {
     num=0
  }
img.src=birds[num].img

num++
})

setInterval(()=>{
  if(num>birds.length-1)
  {
    num=0
  }
img.src=birds[num].img

num++
},1000)
